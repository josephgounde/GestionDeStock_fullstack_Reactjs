# 🚀 Guide de Démarrage Rapide

## ⚡ Installation Express

```bash
# 1. Installer les dépendances
npm install

# 2. Copier le fichier d'environnement
cp .env.example .env

# 3. Démarrer l'application
npm start
```

## 🔧 Configuration Backend

Assurez-vous que le backend Spring Boot est démarré :

```bash
# Dans le dossier gestion-de-stock-api
./mvnw spring-boot:run
```

Le backend doit être accessible sur `http://localhost:8080`

## 👤 Compte de Test

Pour tester l'application, vous pouvez utiliser ces comptes :

**Administrateur :**
- Email: `admin@gestionstock.com`
- Mot de passe: `admin123`

**Utilisateur :**
- Email: `user@gestionstock.com`
- Mot de passe: `user123`

## 📱 Fonctionnalités Disponibles

### ✅ Implémentées
- 🔐 **Authentification** (Login/Logout/Register)
- 📊 **Dashboard** avec statistiques
- 📦 **Articles** (CRUD complet)
- 🏷️ **Catégories** (CRUD complet)
- 👥 **Clients** (CRUD complet)
- 🏢 **Fournisseurs** (CRUD complet)
- 🛒 **Commandes Client** (CRUD de base)
- 🚚 **Commandes Fournisseur** (CRUD de base)
- 📈 **Mouvements de Stock** (Consultation)
- 👤 **Utilisateurs** (CRUD complet)
- ⚙️ **Profil** et changement de mot de passe

### 🔄 Navigation Rapide

| Page | URL | Description |
|------|-----|-------------|
| Dashboard | `/` | Tableau de bord principal |
| Articles | `/articles` | Gestion des produits |
| Catégories | `/categories` | Gestion des catégories |
| Clients | `/clients` | Gestion des clients |
| Fournisseurs | `/fournisseurs` | Gestion des fournisseurs |
| Commandes Client | `/commandesclient` | Commandes des clients |
| Commandes Fournisseur | `/commandesfournisseur` | Commandes aux fournisseurs |
| Mouvements Stock | `/mvtstk` | Historique des mouvements |
| Utilisateurs | `/utilisateurs` | Gestion des utilisateurs |
| Profil | `/profil` | Profil utilisateur |

## 🛠️ Commandes Utiles

```bash
# Démarrage en mode développement
npm start

# Build de production
npm run build

# Lancer les tests
npm test

# Lancer les tests en mode watch
npm run test -- --watch

# Analyser le bundle
npm run build && npx serve -s build
```

## 🐛 Résolution de Problèmes

### Erreur CORS
Si vous rencontrez des erreurs CORS, vérifiez que :
1. Le backend autorise `http://localhost:3000`
2. Le proxy est configuré dans `package.json`

### Erreur 401 (Non autorisé)
1. Vérifiez que le token JWT est valide
2. Reconnectez-vous si nécessaire
3. Vérifiez que le backend est démarré

### Erreur de connexion API
1. Vérifiez que `REACT_APP_API_URL` est correct dans `.env`
2. Vérifiez que le backend est accessible sur le port 8080
3. Testez l'API directement : `curl http://localhost:8080/gestiondestock/v1/articles/all`

## 📊 Structure des Données

### Article
```json
{
  "id": 1,
  "codeArticle": "ART001",
  "designation": "Ordinateur portable",
  "prixUnitaireHt": 800.00,
  "tauxTva": 20,
  "prixUnitaireTtc": 960.00,
  "category": {
    "id": 1,
    "code": "INFO",
    "designation": "Informatique"
  }
}
```

### Client/Fournisseur
```json
{
  "id": 1,
  "nom": "Dupont",
  "prenom": "Jean",
  "mail": "jean.dupont@email.com",
  "numTel": "0123456789",
  "adresse": {
    "adresse1": "123 Rue de la Paix",
    "ville": "Paris",
    "codePostal": "75001",
    "pays": "France"
  }
}
```

## 🎯 Points d'Attention

### Performance
- Les listes sont paginées automatiquement
- Le lazy loading est activé pour les gros composants
- Les images sont optimisées

### Sécurité
- Toutes les routes sont protégées par authentification
- Les tokens JWT expirent automatiquement
- Les données sensibles ne sont pas stockées côté client

### UX/UI
- Interface responsive (mobile/tablet/desktop)
- Thème Material Design cohérent
- Messages d'erreur explicites
- Confirmations pour les actions destructives

## 📞 Support

### Logs de Débogage
```bash
# Activer les logs détaillés
REACT_APP_DEBUG=true npm start
```

### Outils de Développement
- **Redux DevTools** : Inspectez l'état de l'application
- **React Developer Tools** : Analysez les composants
- **Network Tab** : Surveillez les appels API

### Ressources
- [Documentation complète](./README.md)
- [Workflow Backend/Frontend](./WORKFLOW.md)
- [Issues GitHub](https://github.com/votre-repo/issues)

---

🎉 **Félicitations !** Votre application de gestion de stock est maintenant opérationnelle !
