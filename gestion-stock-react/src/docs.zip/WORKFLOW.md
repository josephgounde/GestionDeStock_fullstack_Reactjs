# WORKFLOW - Correspondances Backend ↔ Frontend

## Vue d'ensemble

Ce document détaille les correspondances entre les endpoints du backend Spring Boot et les composants React, ainsi que les workflows utilisateur pour chaque fonctionnalité.

---

## 🔐 **AUTHENTIFICATION**

### Endpoints Backend
- **POST** `/gestiondestock/v1/auth/authenticate`

### Composants React
- **Page** : `Login.tsx`
- **Service** : `authService.authenticate()`
- **Redux Slice** : `authSlice.login`

### Workflow Utilisateur
1. L'utilisateur saisit email/mot de passe dans le formulaire de connexion
2. Appel API POST vers `/auth/authenticate`
3. Réception du token JWT
4. Stockage du token dans localStorage
5. Récupération des informations utilisateur via `/utilisateurs/find/{email}`
6. Redirection vers le dashboard

---

## 📊 **DASHBOARD & STATISTIQUES**

### Endpoints Backend
- **GET** `/gestiondestock/v1/articles/all`
- **GET** `/gestiondestock/v1/categories/all`
- **GET** `/gestiondestock/v1/clients/all`
- **GET** `/gestiondestock/v1/fournisseurs/all`
- **GET** `/gestiondestock/v1/commandesclients/all`
- **GET** `/gestiondestock/v1/commandesfournisseurs/all`

### Composants React
- **Page** : `Dashboard.tsx`
- **Services** : Tous les services (articleService, categoryService, etc.)
- **Redux Slices** : Tous les slices pour récupérer les données

### Workflow Utilisateur
1. Chargement automatique des statistiques au montage du composant
2. Affichage des cartes de statistiques (nombre d'articles, clients, etc.)
3. Mise à jour en temps réel des données

---

## 📦 **GESTION DES ARTICLES**

### Endpoints Backend
- **GET** `/gestiondestock/v1/articles/all` - Liste tous les articles
- **GET** `/gestiondestock/v1/articles/{id}` - Récupère un article par ID
- **POST** `/gestiondestock/v1/articles/create` - Crée un nouvel article
- **DELETE** `/gestiondestock/v1/articles/delete/{id}` - Supprime un article
- **GET** `/gestiondestock/v1/articles/historique/vente/{idArticle}` - Historique des ventes
- **GET** `/gestiondestock/v1/articles/historique/commandeclient/{idArticle}` - Historique commandes client
- **GET** `/gestiondestock/v1/articles/historique/commandefournisseur/{idArticle}` - Historique commandes fournisseur
- **GET** `/gestiondestock/v1/articles/filter/category/{idCategory}` - Articles par catégorie

### Composants React
- **Pages** : `Articles.tsx`, `ArticleForm.tsx`
- **Service** : `articleService`
- **Redux Slice** : `articleSlice`

### Workflow Utilisateur - Lister les articles
1. Navigation vers `/articles`
2. Appel GET `/articles/all`
3. Affichage dans DataGrid avec actions (Voir, Modifier, Supprimer)
4. Possibilité de filtrer et paginer

### Workflow Utilisateur - Créer/Modifier un article
1. Clic sur "Nouvel Article" ou "Modifier"
2. Navigation vers `/nouvelarticle` ou `/nouvelarticle/{id}`
3. Si modification : appel GET `/articles/{id}`
4. Remplissage du formulaire avec validation
5. Calcul automatique du prix TTC
6. Soumission : appel POST `/articles/create`
7. Redirection vers la liste des articles

### Workflow Utilisateur - Supprimer un article
1. Clic sur l'icône "Supprimer"
2. Confirmation via dialog
3. Appel DELETE `/articles/delete/{id}`
4. Mise à jour de la liste

---

## 🏷️ **GESTION DES CATÉGORIES**

### Endpoints Backend
- **GET** `/gestiondestock/v1/categories/all`
- **GET** `/gestiondestock/v1/categories/{id}`
- **POST** `/gestiondestock/v1/categories/create`
- **DELETE** `/gestiondestock/v1/categories/delete/{id}`

### Composants React
- **Pages** : `Categories.tsx`, `CategoryForm.tsx`
- **Service** : `categoryService`
- **Redux Slice** : `categorySlice`

### Workflow Utilisateur
1. **Lister** : GET `/categories/all` → Affichage DataGrid
2. **Créer** : Formulaire → POST `/categories/create`
3. **Modifier** : GET `/categories/{id}` → Formulaire → POST `/categories/create`
4. **Supprimer** : Confirmation → DELETE `/categories/delete/{id}`

---

## 👥 **GESTION DES CLIENTS**

### Endpoints Backend
- **GET** `/gestiondestock/v1/clients/all`
- **GET** `/gestiondestock/v1/clients/{id}`
- **POST** `/gestiondestock/v1/clients/create`
- **DELETE** `/gestiondestock/v1/clients/delete/{id}`

### Composants React
- **Pages** : `Clients.tsx`, `ClientForm.tsx`
- **Service** : `clientService`
- **Redux Slice** : `clientSlice`

### Workflow Utilisateur
1. **Lister** : GET `/clients/all` → DataGrid avec informations contact
2. **Créer/Modifier** : Formulaire avec informations personnelles + adresse
3. **Supprimer** : Confirmation → DELETE `/clients/delete/{id}`

---

## 🏢 **GESTION DES FOURNISSEURS**

### Endpoints Backend
- **GET** `/gestiondestock/v1/fournisseurs/all`
- **GET** `/gestiondestock/v1/fournisseurs/{id}`
- **POST** `/gestiondestock/v1/fournisseurs/create`
- **DELETE** `/gestiondestock/v1/fournisseurs/delete/{id}`

### Composants React
- **Pages** : `Fournisseurs.tsx`, `FournisseurForm.tsx`
- **Service** : `fournisseurService`
- **Redux Slice** : `fournisseurSlice`

### Workflow Utilisateur
Identique aux clients avec les endpoints fournisseurs.

---

## 🛒 **GESTION DES COMMANDES CLIENT**

### Endpoints Backend
- **GET** `/gestiondestock/v1/commandesclients/all`
- **GET** `/gestiondestock/v1/commandesclients/{id}`
- **POST** `/gestiondestock/v1/commandesclients/create`
- **DELETE** `/gestiondestock/v1/commandesclients/delete/{id}`
- **PATCH** `/gestiondestock/v1/commandesclients/update/etat/{id}/{etat}`
- **PATCH** `/gestiondestock/v1/commandesclients/update/quantite/{idCommande}/{idLigneCommande}/{quantite}`
- **PATCH** `/gestiondestock/v1/commandesclients/update/client/{idCommande}/{idClient}`
- **PATCH** `/gestiondestock/v1/commandesclients/update/article/{idCommande}/{idLigneCommande}/{idArticle}`
- **DELETE** `/gestiondestock/v1/commandesclients/delete/article/{idLigneCommande}`

### Composants React
- **Pages** : `CommandesClient.tsx`, `CommandeClientForm.tsx`
- **Service** : `commandeService`
- **Redux Slice** : `commandeSlice`

### Workflow Utilisateur - Créer une commande
1. Navigation vers `/nouvellecommandeclt`
2. Sélection du client via dropdown (données de `/clients/all`)
3. Saisie des informations de base (code, date, état)
4. Ajout de lignes de commande (articles + quantités)
5. Soumission : POST `/commandesclients/create`
6. Redirection vers la liste

### Workflow Utilisateur - Modifier l'état d'une commande
1. Sélection de la commande
2. Changement d'état (EN_PREPARATION → VALIDEE → LIVREE)
3. Appel PATCH `/commandesclients/update/etat/{id}/{etat}`

---

## 🚚 **GESTION DES COMMANDES FOURNISSEUR**

### Endpoints Backend
Similaires aux commandes client mais avec `/commandesfournisseurs/`

### Composants React
- **Pages** : `CommandesFournisseur.tsx`, `CommandeFournisseurForm.tsx`
- **Service** : `commandeService`
- **Redux Slice** : `commandeSlice`

### Workflow Utilisateur
Identique aux commandes client mais avec sélection de fournisseur.

---

## 📈 **GESTION DES MOUVEMENTS DE STOCK**

### Endpoints Backend
- **GET** `/gestiondestock/v1/mvtstk/all`
- **GET** `/gestiondestock/v1/mvtstk/filter/article/{idArticle}`
- **GET** `/gestiondestock/v1/mvtstk/stockreel/{idArticle}`
- **POST** `/gestiondestock/v1/mvtstk/entree`
- **POST** `/gestiondestock/v1/mvtstk/sortie`
- **POST** `/gestiondestock/v1/mvtstk/correctionpos`
- **POST** `/gestiondestock/v1/mvtstk/correctionneg`

### Composants React
- **Page** : `MouvementsStock.tsx`
- **Service** : `mvtStkService`
- **Redux Slice** : `mvtStkSlice`

### Workflow Utilisateur
1. **Consulter** : GET `/mvtstk/all` → DataGrid avec filtres par type/article
2. **Entrée de stock** : Formulaire → POST `/mvtstk/entree`
3. **Sortie de stock** : Formulaire → POST `/mvtstk/sortie`
4. **Corrections** : POST `/mvtstk/correctionpos` ou `/mvtstk/correctionneg`

---

## 👤 **GESTION DES UTILISATEURS**

### Endpoints Backend
- **GET** `/gestiondestock/v1/utilisateurs/all`
- **GET** `/gestiondestock/v1/utilisateurs/{id}`
- **GET** `/gestiondestock/v1/utilisateurs/find/{email}`
- **POST** `/gestiondestock/v1/utilisateurs/create`
- **DELETE** `/gestiondestock/v1/utilisateurs/delete/{id}`
- **POST** `/gestiondestock/v1/utilisateurs/update/password`

### Composants React
- **Pages** : `Utilisateurs.tsx`, `UtilisateurForm.tsx`, `Profil.tsx`, `ChangerMotDePasse.tsx`
- **Service** : `utilisateurService`, `authService`
- **Redux Slice** : `utilisateurSlice`, `authSlice`

### Workflow Utilisateur - Gestion du profil
1. Navigation vers `/profil`
2. Affichage des informations utilisateur connecté
3. Modification des données personnelles
4. Soumission : POST `/utilisateurs/create` (mise à jour)

### Workflow Utilisateur - Changement de mot de passe
1. Navigation vers `/changermotdepasse`
2. Saisie nouveau mot de passe + confirmation
3. Validation côté client
4. Soumission : POST `/utilisateurs/update/password`

---

## 🔒 **SÉCURITÉ ET AUTHENTIFICATION**

### Intercepteurs HTTP
- **Ajout automatique du token JWT** dans les headers `Authorization: Bearer {token}`
- **Gestion des erreurs 401** : déconnexion automatique et redirection vers login
- **Stockage sécurisé** : localStorage pour le token et les informations utilisateur

### Protection des routes
- **ProtectedRoute component** : vérification de l'authentification avant accès
- **Redirection automatique** vers `/login` si non authentifié
- **Vérification de validité du token** au chargement de l'application

---

## 🎯 **POINTS D'INTÉGRATION CLÉS**

### Configuration API
- **Base URL** : `http://localhost:8080/gestiondestock/v1`
- **Proxy** : Configuration dans package.json pour éviter les problèmes CORS
- **Headers** : `Content-Type: application/json` + `Authorization: Bearer {token}`

### Gestion d'état
- **Redux Toolkit** pour la gestion d'état globale
- **Slices** pour chaque entité métier
- **Thunks asynchrones** pour les appels API
- **Gestion centralisée des erreurs**

### Interface utilisateur
- **Material-UI** pour les composants UI
- **DataGrid** pour l'affichage des listes
- **Formulaires réactifs** avec validation
- **Navigation responsive** avec sidebar collapsible

---

## 🚀 **DÉMARRAGE RAPIDE**

### Prérequis
- Node.js 16+
- Java 21
- PostgreSQL
- Backend Spring Boot démarré sur le port 8080

### Commandes
```bash
# Installation des dépendances
npm install

# Démarrage en mode développement
npm start

# Build de production
npm run build

# Tests
npm test
```

### Variables d'environnement
```env
REACT_APP_API_URL=http://localhost:8080/gestiondestock/v1
```

---

## 📝 **NOTES TECHNIQUES**

- **TypeScript** : Typage strict pour une meilleure maintenabilité
- **Hooks personnalisés** : `useAppDispatch` et `useAppSelector` pour Redux
- **Composants fonctionnels** : Utilisation exclusive des hooks React
- **Architecture modulaire** : Séparation claire services/composants/pages
- **Responsive design** : Interface adaptative mobile/desktop
