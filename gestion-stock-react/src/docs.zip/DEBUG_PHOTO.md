# 🔍 **DEBUG - PROBLÈME PHOTO NON AFFICHÉE**

## 🧪 **ÉTAPES DE DEBUG À SUIVRE**

### **1. Vérifier les logs dans la console :**

Quand vous créez un article avec photo, vous devriez voir dans la console :

```
🔄 Début upload photo avec params: {id: X, file: File, title: "...", context: "article"}
📸 Réponse du service photo: {id: X, codeArticle: "...", photo: "https://flickr.com/..."}
✅ article mis à jour avec photo: {...}
🖼️ URL de la photo: https://flickr.com/...
🔄 Mise à jour du store Redux pour article...
✅ Store Redux mis à jour pour article
```

### **2. Si vous ne voyez PAS ces logs :**

**Problème** : Le hook `usePhotoUpload` n'est pas appelé
**Solution** : Vérifiez que `ArticleForm.tsx` utilise bien le hook

### **3. Si vous voyez une erreur :**

**Erreur possible** : `❌ Erreur lors de l'upload de la photo:`
**Action** : Notez l'erreur exacte et vérifiez :
- L'endpoint backend est-il accessible ?
- Le token JWT est-il valide ?
- Le fichier est-il dans le bon format ?

### **4. Si l'upload réussit mais la photo ne s'affiche pas :**

**Vérifiez** :
- L'URL de la photo dans la console : `🖼️ URL de la photo:`
- Cette URL est-elle accessible dans un nouvel onglet ?
- L'article dans le store Redux contient-il bien l'URL ?

### **5. Test manuel de l'endpoint :**

Ouvrez les DevTools → Network et regardez :
- La requête `POST /save/ID/TITLE/article` est-elle envoyée ?
- Quel est le statut de la réponse (200, 404, 500) ?
- Que contient la réponse ?

### **6. Vérifier l'affichage dans DetailArticle :**

Dans `DetailArticle.tsx`, l'image utilise :
```tsx
<img src={articleDto.photo || '/assets/product.png'} />
```

**Vérifiez** :
- `articleDto.photo` contient-il l'URL Flickr ?
- L'image par défaut `/assets/product.png` s'affiche-t-elle ?

## 🔧 **ACTIONS CORRECTIVES POSSIBLES**

### **Si l'endpoint ne répond pas :**
```bash
# Vérifier que le backend est démarré
curl http://localhost:8080/gestiondestock/v1/articles/all
```

### **Si l'URL Flickr ne fonctionne pas :**
- Vérifiez les clés Flickr dans `application.yml`
- Testez l'URL directement dans le navigateur

### **Si le store Redux n'est pas mis à jour :**
- Vérifiez que `updateArticleInList` est bien importé
- Utilisez Redux DevTools pour voir l'état du store

## 📋 **CHECKLIST DE VÉRIFICATION**

- [ ] Console : Logs de debug visibles
- [ ] Network : Requête POST envoyée
- [ ] Backend : Réponse 200 avec URL photo
- [ ] Store Redux : Article mis à jour
- [ ] UI : Image visible dans la liste

**🎯 Suivez ces étapes dans l'ordre et notez à quelle étape ça échoue !**
