# 📸 **GUIDE DE TEST - UPLOAD ET AFFICHAGE DES PHOTOS**

## 🎯 **OBJECTIF**
Vérifier que les photos s'affichent correctement dans les listes après création/modification des entités.

## 🔧 **CORRECTIONS APPORTÉES**

### **1. URL Endpoint corrigée :**
```typescript
// AVANT (incorrect)
`/gestiondestock/v1/save/${params.id}/${params.title}/${params.context}`

// APRÈS (correct)
`/save/${params.id}/${params.title}/${params.context}`
```

### **2. Hook personnalisé créé :**
- **`usePhotoUpload`** : Gère l'upload + mise à jour automatique du store Redux
- **Actions Redux** : `updateArticleInList`, `updateClientInList`, etc.

### **3. Composants mis à jour :**
- **`ImageUpload`** : Utilise le hook pour mise à jour automatique
- **`ArticleForm`** : Upload simplifié avec hook
- **Tous les slices** : Actions de mise à jour ajoutées

## 🧪 **TESTS À EFFECTUER**

### **Test 1 : Création d'article avec photo**
1. **Aller sur** : `/nouvelarticle`
2. **Remplir** : Code, Désignation, Prix, Catégorie
3. **Sélectionner une photo** via le bouton upload
4. **Cliquer** "Enregistrer"
5. **Vérifier** : Redirection vers `/articles`
6. **✅ RÉSULTAT ATTENDU** : Photo visible dans la liste

### **Test 2 : Modification d'article existant**
1. **Aller sur** : `/articles`
2. **Cliquer** "Modifier" sur un article
3. **Changer la photo** via ImageUpload
4. **Sauvegarder**
5. **✅ RÉSULTAT ATTENDU** : Nouvelle photo visible immédiatement

### **Test 3 : Création de client avec photo**
1. **Aller sur** : `/nouveauclient`
2. **Remplir** les informations client
3. **Ajouter une photo**
4. **Sauvegarder**
5. **✅ RÉSULTAT ATTENDU** : Photo visible dans `/clients`

### **Test 4 : Vérification console**
1. **Ouvrir** DevTools (F12)
2. **Effectuer** un upload de photo
3. **Vérifier** les logs :
   ```
   Article mis à jour avec photo: { id: X, photo: "https://flickr.com/..." }
   ```

## 🔍 **POINTS DE VÉRIFICATION**

### **Backend :**
- ✅ **Flickr Service** : Photos uploadées sur Flickr
- ✅ **Strategy Pattern** : Contexte correct (article, client, etc.)
- ✅ **Retour API** : DTO complet avec URL photo

### **Frontend :**
- ✅ **Store Redux** : Entité mise à jour dans la liste
- ✅ **Composant ImageUpload** : Preview et callback fonctionnels
- ✅ **Navigation** : Pas de rechargement nécessaire

## 🚨 **PROBLÈMES POSSIBLES**

### **Photo ne s'affiche pas :**
1. **Vérifier** l'URL dans la console : `updatedEntity.photo`
2. **Vérifier** l'endpoint : `/save/ID/TITLE/CONTEXT`
3. **Vérifier** Flickr API : Clés configurées dans `application.yml`

### **Erreur CORS :**
```
Access to XMLHttpRequest blocked by CORS policy
```
**Solution** : Vérifier que `http://localhost:3000` est dans la config CORS

### **Erreur 500 :**
```
Internal Server Error
```
**Solution** : Vérifier les logs Spring Boot pour détails

## 📊 **FLUX COMPLET VÉRIFIÉ**

```mermaid
graph TD
    A[Création Entité] --> B[Sauvegarde avec ID]
    B --> C[Upload Photo]
    C --> D[Backend: Strategy Pattern]
    D --> E[Flickr: Stockage Image]
    E --> F[Retour: DTO + URL Photo]
    F --> G[Frontend: Hook usePhotoUpload]
    G --> H[Redux: updateEntityInList]
    H --> I[UI: Photo visible dans liste]
```

## ✅ **VALIDATION FINALE**

### **Critères de succès :**
- [ ] Photos visibles immédiatement après création
- [ ] Pas de rechargement de page nécessaire
- [ ] Console sans erreurs
- [ ] URLs Flickr valides
- [ ] Store Redux synchronisé

### **Entités testées :**
- [ ] Articles
- [ ] Clients  
- [ ] Fournisseurs
- [ ] Utilisateurs

**🎉 Si tous les tests passent, la gestion des photos est entièrement fonctionnelle !**
